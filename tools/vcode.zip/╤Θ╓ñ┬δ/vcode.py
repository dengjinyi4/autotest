#!/usr/bin/env python
# encoding: utf-8
import os,time,datetime,requests
from pytesser import *
from PIL import Image,ImageEnhance 
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
if __name__ == '__main__':
    rr=requests.session()
    rr.get('https://www.yiqifa.com/front/')
    res=rr.get('https://www.yiqifa.com/front/common/getcode?sessionId=')
    f = open('1.png', 'wb')
    f.write(res.content)
    f.close()
    img = Image.open('1.png')
    img.load()
    img.show()
    # #亮度增强  
    img = ImageEnhance.Brightness(img)  
    brightness = 2  
    img = img.enhance(brightness)  
    img.show()
    # 
    # img.convert('L')
    # img.show()
    #锐度增强 
    # img = ImageEnhance.Sharpness(img)  
    # sharpness = 5.0  
    # img = img.enhance(sharpness)  
    # img.show()
    # #色度增强  
    # img = ImageEnhance.Color(img)  
    # color = 3.5  
    # img = img.enhance(color)  
    # img.show()  
    # pytesseract.image_to_data()
    #对比度增强  
    # img = ImageEnhance.Contrast(img)  
    # contrast = 2.5  
    # img = img.enhance(contrast)  
    # img.show()
    #使用ImageEnhance可以增强图片的识别率  
    img = ImageEnhance.Contrast(img) 
    img = img.enhance(20) 

    vcode=image_to_string(img)
    print vcode
    print type(vcode)
# http://www.th7.cn/Program/Python/201602/768304.shtml  详细的配置说明